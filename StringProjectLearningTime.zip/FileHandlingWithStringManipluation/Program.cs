﻿// See https://aka.ms/new-console-template for more information
using System.IO;

string maxValue="";
string reversedWord = "";
string result="";

Console.WriteLine("File Handling With String Manipulation!");
Console.WriteLine("----------------------------------------");

string inputPath = @"D:\Projects\LearningProjects\FileHandlingWithStringManipluation\InputString.txt";
string outputPath = @"D:\Projects\LearningProjects\FileHandlingWithStringManipluation\OutPutString.txt";

bool IsCheckFileInput = File.Exists(inputPath);
bool IsCheckFileOutput = File.Exists(outputPath);

if(IsCheckFileInput == false)
{
  Console.WriteLine("Your file Directory is Not Found so this Process  Create  New File:");
  Console.WriteLine("Please enter a paragraph: ");
  string paragraph = Console.ReadLine();
  Console.WriteLine();
    
  using(FileStream CreateFileInput = File.Create(inputPath))  
  {
	  using(StreamWriter writerInput = new StreamWriter(CreateFileInput))
	  {
            writerInput.WriteLine(paragraph);
	  }	  
	  
  }	
}

if(IsCheckFileInput = true)
{
     string readfile = File.ReadAllText(inputPath);
	 Console.WriteLine(readfile);
     var words = readfile.Split(' ');
				
	 Console.WriteLine("Total words Count: {0}",words.Length);
	
	if(words.Length % 2 == 0)
	   { 
		  int num1 = words.Length / 2;
		  result = words[num1].ToString();
		  Console.WriteLine("The Middle word:{0} Count is even",result);
	   }
	   else
	   {
		  int num2 = words.Length / 2;
		  result = words[num2].ToString();
		  Console.WriteLine("The Middle word is:{0}  Count is odd Number",result);
	   }
	   
	string MinimumchaarcterWord = words[0];
										
	foreach(var word in words)
	{
	   if(word.Length > maxValue.Length)
	   {
		  maxValue = word;
	   }
	   if(word.Length < MinimumchaarcterWord.Length)
	   {
		   MinimumchaarcterWord = word;
	   }
	}
	
	foreach (string s in words.Reverse())
		{
			reversedWord += s+" ";
		}
	 
    string[] alreadyProcessedWords = new string[words.Length];
    string[]  repeatedWordsPrint = new string[words.Length];
	for (int i = 0; i < words.Length; i++)
	{
		var IsprocessWord = false;
		
		foreach(var processWord in alreadyProcessedWords)
		{ 
		  if(processWord == words[i])
		  {
			  IsprocessWord = true;
		  }
		}
		
		if( IsprocessWord == false)		
		{  
			 int count=0;
							
			for (int j = 0 ; j < words.Length; j++) 
			{
		
				if (words[i] == words[j])
				{			 
				 count=count+1;
				}
			}
			
			if(count > 1)
			{
			
		          Console.WriteLine("RepeatedWord: {0} : Count is :{1}", words[i] ,count);
				  repeatedWordsPrint[i] = ($"RepeatedWord: {words[i]} : Count is :{count}");		
			}
			
			alreadyProcessedWords[i] = words[i];
		}
	}								
    Console.WriteLine("MaxLength word: {0} Count: {1}",maxValue,maxValue.Length);		
	Console.WriteLine("MinimalLength word: {0} Count: {1}",MinimumchaarcterWord,MinimumchaarcterWord.Length);
	Console.WriteLine("ReversedWord From Given String: {0}",reversedWord);

	if(IsCheckFileOutput == false)
	{
		using(FileStream fileoutput = File.Create(outputPath))	
		{
		 using(StreamWriter writer = new StreamWriter(fileoutput))
		 {
			 writer.WriteLine($"Total words Count: {words.Length}");
			 writer.WriteLine($"MaxLength word: {maxValue} Count: {maxValue.Length}");
			 
			 writer.WriteLine($"MinimalLength word: {MinimumchaarcterWord} Count: {MinimumchaarcterWord.Length}");
			 writer.WriteLine($"The Middle word:{result} Count is even");
			 
			 writer.WriteLine($"The Middle word is:{result}  Count is odd Number");
			 writer.WriteLine();
			 
			 writer.WriteLine($" ReversedWord From Given String: \n {reversedWord}");
			 writer.WriteLine();
			foreach(var repeatedWordsPrinToNotepad in  repeatedWordsPrint)
			{
				writer.WriteLine(repeatedWordsPrinToNotepad);
			}				
		 }  
	}
	
	} 
		if(IsCheckFileOutput == true)
		{
		 using(StreamWriter writer = new StreamWriter(outputPath))
		 {
			 writer.WriteLine($"Total words Count: {words.Length}");
			 writer.WriteLine($"MaxLength word: {maxValue} Count: {maxValue.Length}");
			 
			 writer.WriteLine($"MinimalLength word: {MinimumchaarcterWord} Count: {MinimumchaarcterWord.Length}");
			 writer.WriteLine($"The Middle word:{result} Count is even");
			 
			 writer.WriteLine($"The Middle word is:{result}  Count is odd Number");
			 writer.WriteLine();
			
			writer.WriteLine($" ReversedWord From Given String: \n {reversedWord}");
			 writer.WriteLine();
			 
			foreach(var  repeatedWordsPrinToNotepad in repeatedWordsPrint)
			{
             	if(repeatedWordsPrinToNotepad != null)
				{	  
				 writer.WriteLine(repeatedWordsPrinToNotepad);
				}
			}	
		}  

	}

 }

 
	
