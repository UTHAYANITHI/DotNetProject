﻿// See https://aka.ms/new-console-template for more information
             double num=0;
			 Console.WriteLine("enter the value: ");
			 double.TryParse(Console.ReadLine(),out num);
			 Console.WriteLine();
			 
		     if(num % 2 == 0)
			   {
				   
				  double  num1 = num / 2;
				  Console.WriteLine("The Number:{0} is even",num1);
			   }
			 else
			   {
				 double num2 = num / 2;
				 Console.WriteLine(" The Number:{0} is odd",num2);
				 Console.WriteLine("Rounded value is: {0}" ,Math.Round(num2));
			   }
			   
			 