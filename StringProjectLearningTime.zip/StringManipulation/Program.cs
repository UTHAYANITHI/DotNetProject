﻿using System;
namespace StringManipulation
{ 
	  public class Program
	  {
		private static void Main(string[] args)
	   
			{
				string maxValue="";
				string reversedWord = "";
				string result="";
			
																	
				Console.WriteLine("String Manipulation");
				Console.WriteLine("------------------------------");
				
				Console.WriteLine("Please enter a paragraph: ");
				string paragraph = Console.ReadLine();
				Console.WriteLine();
				
				int paragraphCharactersCount = paragraph.Length;
		     	Console.WriteLine("Total characters count: {0}", paragraphCharactersCount);
				
				var words = paragraph.Split(' ');
				
			    Console.WriteLine("Total words Count: {0}",words.Length);
				
				if(words.Length % 2 == 0)
				   {
					   
					  int num1 = words.Length / 2;
				      result = words[num1].ToString();
					  Console.WriteLine("The Middle word:{0} Count is even",result);
				   }
				   else
				   {
					  int num2 = words.Length / 2;
					  result = words[num2].ToString();
					  Console.WriteLine("The Middle word is:{0}  Count is odd Number",result);
					
				   }
				   
				string MinimumchaarcterWord = words[0];
													
				foreach(var word in words)
				{
				   if(word.Length > maxValue.Length)
				   {
					  maxValue = word;
				   }
				   if(word.Length < MinimumchaarcterWord.Length)
				   {
					   MinimumchaarcterWord=word;
				   }
				}
				
			    // for (int i = words.Length-1; i>=0;i--)
				// {
					// reversedWord += words[i]+" ";					
				// }
				
				foreach (string s in words.Reverse())
					{
						reversedWord +=s+" ";
					}
				 
			   string[] alreadyProcessedWords = new string[words.Length];

			  
		        
   				for (int i = 0; i < words.Length; i++)
				{
					var IsprocessWord = false;
					
					foreach(var processWord in alreadyProcessedWords)
					{ 
					  if(processWord == words[i])
					  {
						  IsprocessWord = true;
					  }
					}
					
					if( IsprocessWord == false)		
					{  
				         int count=0;
										
						for (int j = 0 ; j < words.Length; j++) 
						{
					
							if (words[i] == words[j])
							{			 
							 count=count+1;
							}
						}
						
						if(count > 1)
						{	
	
						Console.WriteLine("RepeatedWord: {0} : Count is :{1}", words[i] ,count);
						}
						
					    alreadyProcessedWords[i] = words[i];
                       
					}
				 
				  
				}
				   
															
            	 Console.WriteLine("MaxLength word: {0} Count: {1}",maxValue,maxValue.Length);		
				 Console.WriteLine("MinimalLength word: {0} Count: {1}",MinimumchaarcterWord,MinimumchaarcterWord.Length);
   				 Console.WriteLine("ReversedWord From Given String: {0}",reversedWord);
				 
				 
				 
			}
	  }
} 
